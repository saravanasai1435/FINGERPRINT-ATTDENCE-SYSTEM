#!/usr/bin/env python3
"""
Parametric enclosure for the ESP32-S3 + R307 + 1.3" OLED fingerprint attendance device.
Generates: attendance_box.stl and attendance_lid.stl (both in PRINT orientation).

All sizes in mm. MEASURE YOUR PARTS WITH CALIPERS and edit the numbers below,
then run:  pip install trimesh manifold3d numpy   &&   python gen_enclosure.py
"""
import numpy as np
import trimesh
from trimesh.boolean import union, difference

# ======================= PARAMETERS (edit these) =======================
# --- enclosure ---
IX, IY, IZ = 108.0, 78.0, 38.0     # interior size (X width, Y height, Z depth)
WT, FT, LT = 2.4, 2.4, 3.2         # wall, floor, lid thickness
POST_OD, POST_HOLE = 7.2, 2.7      # corner screw posts (M3 self-tapping / M3 heat-insert 4.0)
LID_HOLE, LID_CB_D, LID_CB_H = 3.4, 6.4, 1.9   # M3 clearance + counterbore for screw head

# --- R307 fingerprint sensor (typical 56 x 20 x 21.5 body) ---
SENS_L, SENS_W = 56.0, 20.0        # body footprint seen from the top (L along X)
SENS_CX, SENS_CY = IX / 2, 17.0    # centre in interior coordinates
SENS_WIN_L, SENS_WIN_W = 20.0, 17.0  # opening for the glass window in the lid
SENS_WIN_DX = 0.0                  # shift window along X relative to body centre (measure!)
CRADLE_T, CRADLE_H, CRADLE_CLR = 2.0, 12.0, 0.3
CABLE_SLOT_W = 14.0                # cable exit on the +X end of the cradle

# --- 1.3" OLED module (typical SH1106 PCB 35.4 x 33.5) ---
OLED_W, OLED_H = 35.4, 33.5
OLED_CX, OLED_CY = IX / 2 - 4, 57.5
OLED_WIN_W, OLED_WIN_H = 30.5, 16.5   # opening for the active area
OLED_WIN_DY = 3.0                  # window centre above PCB centre (toward the top of the device)
OLED_CLIP_T, OLED_CLIP_L, OLED_CLIP_H = 1.4, 6.0, 4.0

# --- LED and switch ---
LED_X, LED_Y, LED_D = 92.0, 47.0, 5.2       # 5 mm LED
SW_X, SW_Y, SW_D = 92.0, 62.0, 12.2         # 12 mm push button

# --- ESP32-S3-DevKitC-1 (69.6 x 25.4, no mounting holes) ---
ESP_L, ESP_W, ESP_PCB = 70.0, 25.6, 1.6
ESP_X0 = 0.8                       # board left end (USB end) from interior left wall
ESP_CY = 57.5
RAIL_W, RAIL_H = 12.0, 20.0        # centre rail between the pin rows; 20 mm leaves room for dupont plugs
GUIDE_T, GUIDE_L, GUIDE_UP = 1.6, 7.0, 6.0
USB_SLOT_W, USB_SLOT_H = 24.0, 9.0

# --- wall-mount keyholes (in the back/floor) ---
KEY_HEAD, KEY_SHAFT, KEY_SLOT = 7.6, 3.6, 6.0
KEY_Y = 15.0
KEY_X_OFF = 12.0

# ======================= helpers =======================
EX, EY = IX + 2 * WT, IY + 2 * WT
EZ = FT + IZ          # box height (rim)


def box(x0, y0, z0, x1, y1, z1):
    m = trimesh.creation.box(extents=[x1 - x0, y1 - y0, z1 - z0])
    m.apply_translation([(x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2])
    return m


def cyl(x, y, z0, z1, r, sec=64):
    m = trimesh.creation.cylinder(radius=r, height=z1 - z0, sections=sec)
    m.apply_translation([x, y, (z0 + z1) / 2])
    return m


def U(parts):
    return union(parts, engine="manifold")


def D(base, cutters):
    return difference([base] + cutters, engine="manifold")


def ix(x):   # interior x -> exterior x
    return WT + x


def iy(y):
    return WT + y


# screw post centres (interior coords)
POSTS = [(4.5, 4.5), (IX - 4.5, 4.5), (4.5, IY - 4.5), (IX - 4.5, IY - 4.5)]

# ======================= BOX =======================
def build_box():
    shell = D(box(0, 0, 0, EX, EY, EZ), [box(WT, WT, FT, WT + IX, WT + IY, EZ + 1)])
    parts = [shell]

    # corner posts
    for (px, py) in POSTS:
        parts.append(cyl(ix(px), iy(py), FT - 0.2, EZ, POST_OD / 2))

    # ESP32 centre rail
    bx0 = ix(ESP_X0)
    bx1 = bx0 + ESP_L
    parts.append(box(bx0 + 2, iy(ESP_CY) - RAIL_W / 2, FT - 0.2, bx1 - 2, iy(ESP_CY) + RAIL_W / 2, FT + RAIL_H))

    # board guides (L-shaped at the four corners; left side walls only so USB end stays open)
    ytop = iy(ESP_CY) + ESP_W / 2 + 0.4
    ybot = iy(ESP_CY) - ESP_W / 2 - 0.4
    gz1 = FT + RAIL_H + ESP_PCB + GUIDE_UP
    for yedge, sgn in ((ytop, +1), (ybot, -1)):
        ya, yb = (yedge, yedge + GUIDE_T) if sgn > 0 else (yedge - GUIDE_T, yedge)
        # side walls, left end and right end
        parts.append(box(bx0, ya, FT - 0.2, bx0 + GUIDE_L, yb, gz1))
        parts.append(box(bx1 - GUIDE_L, ya, FT - 0.2, bx1 + 0.4 + GUIDE_T, yb, gz1))
        # right end stop wall
        if sgn > 0:
            parts.append(box(bx1 + 0.4, yedge - GUIDE_L, FT - 0.2, bx1 + 0.4 + GUIDE_T, yedge + GUIDE_T, gz1))
        else:
            parts.append(box(bx1 + 0.4, yedge - GUIDE_T, FT - 0.2, bx1 + 0.4 + GUIDE_T, yedge + GUIDE_L, gz1))

    body = U(parts)

    cuts = []
    # screw pilot holes in posts (blind, from the rim down)
    for (px, py) in POSTS:
        cuts.append(cyl(ix(px), iy(py), EZ - 14, EZ + 1, POST_HOLE / 2, 32))
    # USB slot in the left wall (ESP32 USB end)
    zc = FT + RAIL_H + ESP_PCB + 1.6
    cuts.append(box(-1, iy(ESP_CY) - USB_SLOT_W / 2, zc - USB_SLOT_H / 2, WT + 0.6, iy(ESP_CY) + USB_SLOT_W / 2, zc + USB_SLOT_H / 2))
    # keyholes in the floor
    for kx in (ix(KEY_X_OFF), ix(IX - KEY_X_OFF)):
        ky = iy(KEY_Y)
        cuts.append(cyl(kx, ky, -1, FT + 1, KEY_HEAD / 2))
        cuts.append(box(kx - KEY_SHAFT / 2, ky, -1, kx + KEY_SHAFT / 2, ky + KEY_SLOT, FT + 1))
        cuts.append(cyl(kx, ky + KEY_SLOT, -1, FT + 1, KEY_SHAFT / 2, 32))
    return D(body, cuts)


# ======================= LID (print orientation: outer face on the bed, z=0) =======================
def LY(y):  # assembled-top-view y -> print-orientation y (lid is flipped over the X axis)
    return EY - y


def build_lid():
    plate = box(0, 0, 0, EX, EY, LT)
    cuts = []
    # sensor window
    cuts.append(box(ix(SENS_CX + SENS_WIN_DX) - SENS_WIN_L / 2, LY(iy(SENS_CY)) - SENS_WIN_W / 2, -1,
                    ix(SENS_CX + SENS_WIN_DX) + SENS_WIN_L / 2, LY(iy(SENS_CY)) + SENS_WIN_W / 2, LT + 1))
    # OLED window (offset toward the top of the device)
    cy = LY(iy(OLED_CY + OLED_WIN_DY))
    cuts.append(box(ix(OLED_CX) - OLED_WIN_W / 2, cy - OLED_WIN_H / 2, -1,
                    ix(OLED_CX) + OLED_WIN_W / 2, cy + OLED_WIN_H / 2, LT + 1))
    # LED and switch
    cuts.append(cyl(ix(LED_X), LY(iy(LED_Y)), -1, LT + 1, LED_D / 2))
    cuts.append(cyl(ix(SW_X), LY(iy(SW_Y)), -1, LT + 1, SW_D / 2))
    # screw holes with counterbore on the outer face
    for (px, py) in POSTS:
        cuts.append(cyl(ix(px), LY(iy(py)), -1, LT + 1, LID_HOLE / 2, 32))
        cuts.append(cyl(ix(px), LY(iy(py)), -1, LID_CB_H, LID_CB_D / 2, 32))
    lid = D(plate, cuts)

    adds = [lid]
    # sensor cradle (ring under the lid), with a cable slot on the +X end
    sx, sy = ix(SENS_CX), LY(iy(SENS_CY))
    ix0, ix1 = sx - SENS_L / 2 - CRADLE_CLR, sx + SENS_L / 2 + CRADLE_CLR
    iy0, iy1 = sy - SENS_W / 2 - CRADLE_CLR, sy + SENS_W / 2 + CRADLE_CLR
    ring = D(box(ix0 - CRADLE_T, iy0 - CRADLE_T, LT - 0.2, ix1 + CRADLE_T, iy1 + CRADLE_T, LT + CRADLE_H),
             [box(ix0, iy0, LT - 1, ix1, iy1, LT + CRADLE_H + 1),
              box(ix1 - 1, sy - CABLE_SLOT_W / 2, LT + 0.0, ix1 + CRADLE_T + 1, sy + CABLE_SLOT_W / 2, LT + CRADLE_H + 1)])
    adds.append(ring)

    # OLED pocket: four L-shaped corner clips around the PCB
    ox, oy = ix(OLED_CX), LY(iy(OLED_CY))
    hw, hh = OLED_W / 2 + 0.25, OLED_H / 2 + 0.25
    t, L, h = OLED_CLIP_T, OLED_CLIP_L, OLED_CLIP_H
    for sx_ in (-1, 1):
        for sy_ in (-1, 1):
            cx_, cy_ = ox + sx_ * hw, oy + sy_ * hh
            # wall along X (at y edge) and along Y (at x edge)
            xa, xb = sorted([cx_, cx_ - sx_ * L])
            ya, yb = (cy_, cy_ + sy_ * t) if sy_ > 0 else (cy_ - t, cy_)
            adds.append(box(xa, min(ya, yb), LT - 0.2, xb, max(ya, yb), LT + h))
            ya2, yb2 = sorted([cy_, cy_ - sy_ * L])
            xa2, xb2 = (cx_, cx_ + sx_ * t) if sx_ > 0 else (cx_ - t, cx_)
            adds.append(box(min(xa2, xb2), ya2, LT - 0.2, max(xa2, xb2), yb2, LT + h))

    # LED holder boss
    boss = D(cyl(ix(LED_X), LY(iy(LED_Y)), LT - 0.2, LT + 3.5, 4.8, 48),
             [cyl(ix(LED_X), LY(iy(LED_Y)), LT - 1, LT + 4, LED_D / 2, 48)])
    adds.append(boss)
    return U(adds)


# ======================= build + sanity checks =======================
if __name__ == "__main__":
    b, l = build_box(), build_lid()
    b.export("attendance_box.stl")
    l.export("attendance_lid.stl")
    for name, m in (("box", b), ("lid", l)):
        print(f"{name}: watertight={m.is_watertight} volume={m.volume/1000:.1f} cm3 "
              f"size={np.round(m.bounds[1] - m.bounds[0], 1)}")

    # --- collision check with dummy parts in the ASSEMBLED position ---
    # lid, flipped back to assembled orientation, sits on top at z = EZ
    lid_asm = l.copy()
    lid_asm.apply_transform(trimesh.transformations.rotation_matrix(np.pi, [1, 0, 0]))
    lid_asm.apply_translation([0, EY, EZ + LT])

    esp = box(ix(ESP_X0), iy(ESP_CY) - 12.7, FT + RAIL_H, ix(ESP_X0) + 69.6, iy(ESP_CY) + 12.7, FT + RAIL_H + ESP_PCB + 3.5)
    r307 = box(ix(SENS_CX) - SENS_L / 2, iy(SENS_CY) - SENS_W / 2, EZ - 21.5, ix(SENS_CX) + SENS_L / 2, iy(SENS_CY) + SENS_W / 2, EZ)
    oled = box(ix(OLED_CX) - OLED_W / 2, iy(OLED_CY) - OLED_H / 2, EZ - 3.2, ix(OLED_CX) + OLED_W / 2, iy(OLED_CY) + OLED_H / 2, EZ)
    sw = cyl(ix(SW_X), iy(SW_Y), EZ - 22, EZ, 6.0)
    for pname, p in (("ESP32", esp), ("R307", r307), ("OLED", oled), ("switch", sw)):
        for hname, host in (("box", b), ("lid", lid_asm)):
            try:
                v = trimesh.boolean.intersection([p, host], engine="manifold").volume
            except Exception:
                v = 0.0
            flag = "OK " if v < 5.0 else "CLASH"
            print(f"  {flag} {pname} vs {hname}: overlap {v:.1f} mm3")
    print(f"outer size assembled: {EX:.1f} x {EY:.1f} x {EZ + LT:.1f} mm")
